
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jinonethreefiveeight.mixedore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.jinonethreefiveeight.mixedore.world.features.ores.MixedOreFeature;
import net.jinonethreefiveeight.mixedore.world.features.ores.DeepslateMixedOreFeature;
import net.jinonethreefiveeight.mixedore.MixedOreMod;

@Mod.EventBusSubscriber
public class MixedOreModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, MixedOreMod.MODID);
	public static final RegistryObject<Feature<?>> MIXED_ORE = REGISTRY.register("mixed_ore", MixedOreFeature::feature);
	public static final RegistryObject<Feature<?>> DEEPSLATE_MIXED_ORE = REGISTRY.register("deepslate_mixed_ore", DeepslateMixedOreFeature::feature);
}

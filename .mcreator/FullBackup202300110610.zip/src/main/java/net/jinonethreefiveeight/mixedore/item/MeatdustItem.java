
package net.jinonethreefiveeight.mixedore.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

import net.jinonethreefiveeight.mixedore.init.MixedOreModTabs;

public class MeatdustItem extends Item {
	public MeatdustItem() {
		super(new Item.Properties().tab(MixedOreModTabs.TAB_MIXED_ORE_T).stacksTo(64).rarity(Rarity.COMMON).food((new FoodProperties.Builder()).nutrition(7).saturationMod(0.5f).alwaysEat().meat().build()));
	}
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jinonethreefiveeight.mixedore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.biome.Biome;

import net.jinonethreefiveeight.mixedore.world.biome.NetherstoneBiome;
import net.jinonethreefiveeight.mixedore.world.biome.DeepstaleBiome;
import net.jinonethreefiveeight.mixedore.MixedOreMod;

public class MixedOreModBiomes {
	public static final DeferredRegister<Biome> REGISTRY = DeferredRegister.create(ForgeRegistries.BIOMES, MixedOreMod.MODID);
	public static final RegistryObject<Biome> DEEPSTALE = REGISTRY.register("deepstale", DeepstaleBiome::createBiome);
	public static final RegistryObject<Biome> NETHERSTONE = REGISTRY.register("netherstone", NetherstoneBiome::createBiome);
}

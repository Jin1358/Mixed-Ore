
package net.jinonethreefiveeight.mixedore.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

import net.jinonethreefiveeight.mixedore.init.MixedOreModTabs;

public class NetheriteDustItem extends Item {
	public NetheriteDustItem() {
		super(new Item.Properties().tab(MixedOreModTabs.TAB_MIXED_ORE_T).stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}

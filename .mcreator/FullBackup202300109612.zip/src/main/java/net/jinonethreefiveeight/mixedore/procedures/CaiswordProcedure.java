package net.jinonethreefiveeight.mixedore.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.jinonethreefiveeight.mixedore.init.MixedOreModItems;

public class CaiswordProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == MixedOreModItems.MIXED_ORE_SWORD_GOD.get()) {
			return true;
		}
		return false;
	}
}

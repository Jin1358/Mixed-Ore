package net.jinonethreefiveeight.mixedore.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;

import net.jinonethreefiveeight.mixedore.init.MixedOreModItems;

public class DiefuckProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if ((sourceentity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(MixedOreModItems.MIXED_ORE_SWORD_GOD.get())) : false)
				|| (sourceentity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(MixedOreModItems.MIXEDOREGODBOW.get())) : false)) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeAllEffects();
			entity.hurt(DamageSource.IN_FIRE, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.LIGHTNING_BOLT, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.ON_FIRE, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.LAVA, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.HOT_FLOOR, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.IN_WALL, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.CRAMMING, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.DROWN, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.STARVE, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.CACTUS, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.GENERIC, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.FLY_INTO_WALL, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.OUT_OF_WORLD, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.MAGIC, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.WITHER, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.ANVIL, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.FALLING_BLOCK, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.DRAGON_BREATH, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.DRY_OUT, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.SWEET_BERRY_BUSH, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.FREEZE, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.FALLING_STALACTITE, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.STALAGMITE, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.OUT_OF_WORLD, (float) Double.POSITIVE_INFINITY);
			if (entity instanceof LivingEntity _entity)
				_entity.removeAllEffects();
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) Double.NEGATIVE_INFINITY);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) Double.NEGATIVE_INFINITY);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) Double.NEGATIVE_INFINITY);
			entity.hurt(DamageSource.OUT_OF_WORLD, (float) Double.POSITIVE_INFINITY);
			entity.hurt(DamageSource.OUT_OF_WORLD, (float) Double.POSITIVE_INFINITY);
			if (entity.isAlive()) {
				if (entity instanceof LivingEntity _entity)
					_entity.removeAllEffects();
				for (int index0 = 0; index0 < (int) (Double.POSITIVE_INFINITY); index0++) {
					if (entity instanceof LivingEntity _entity)
						_entity.removeAllEffects();
					entity.hurt(DamageSource.IN_FIRE, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.LIGHTNING_BOLT, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.ON_FIRE, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.LAVA, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.HOT_FLOOR, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.IN_WALL, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.CRAMMING, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.DROWN, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.STARVE, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.CACTUS, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.GENERIC, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.FLY_INTO_WALL, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.OUT_OF_WORLD, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.MAGIC, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.WITHER, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.ANVIL, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.FALLING_BLOCK, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.DRAGON_BREATH, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.DRY_OUT, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.SWEET_BERRY_BUSH, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.FREEZE, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.FALLING_STALACTITE, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.STALAGMITE, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.OUT_OF_WORLD, (float) Double.POSITIVE_INFINITY);
					if (entity instanceof LivingEntity _entity)
						_entity.removeAllEffects();
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) Double.NEGATIVE_INFINITY);
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) Double.NEGATIVE_INFINITY);
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) Double.NEGATIVE_INFINITY);
					entity.hurt(DamageSource.OUT_OF_WORLD, (float) Double.POSITIVE_INFINITY);
					entity.hurt(DamageSource.OUT_OF_WORLD, (float) Double.POSITIVE_INFINITY);
				}
			}
		}
	}
}


package net.jinonethreefiveeight.mixedore.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

import net.jinonethreefiveeight.mixedore.init.MixedOreModTabs;

public class CoalDustItem extends Item {
	public CoalDustItem() {
		super(new Item.Properties().tab(MixedOreModTabs.TAB_MIXED_ORE_T).stacksTo(64).rarity(Rarity.COMMON));
	}
}

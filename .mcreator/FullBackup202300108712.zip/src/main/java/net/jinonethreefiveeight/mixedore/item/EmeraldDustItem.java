
package net.jinonethreefiveeight.mixedore.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

import net.jinonethreefiveeight.mixedore.init.MixedOreModTabs;

public class EmeraldDustItem extends Item {
	public EmeraldDustItem() {
		super(new Item.Properties().tab(MixedOreModTabs.TAB_MIXED_ORE_T).stacksTo(64).rarity(Rarity.COMMON));
	}
}

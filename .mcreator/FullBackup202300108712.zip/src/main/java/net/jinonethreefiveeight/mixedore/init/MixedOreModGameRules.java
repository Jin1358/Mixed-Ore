
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jinonethreefiveeight.mixedore.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MixedOreModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> BLOCKLITEM = GameRules.register("blocklItem", GameRules.Category.MISC, GameRules.BooleanValue.create(false));
}

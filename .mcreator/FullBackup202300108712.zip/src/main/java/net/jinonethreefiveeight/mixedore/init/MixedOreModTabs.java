
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jinonethreefiveeight.mixedore.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class MixedOreModTabs {
	public static CreativeModeTab TAB_MIXED_ORE_T;

	public static void load() {
		TAB_MIXED_ORE_T = new CreativeModeTab("tabmixed_ore_t") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(MixedOreModItems.MIXED_ORE_INGOT.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}

package net.jinonethreefiveeight.mixedore.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;

import net.jinonethreefiveeight.mixedore.init.MixedOreModItems;

public class DiefuckProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if ((sourceentity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(MixedOreModItems.MIXED_ORE_SWORD_GOD.get())) : false)
				|| (sourceentity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(MixedOreModItems.MIXEDOREGODBOW.get())) : false)) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeAllEffects();
			entity.hurt(DamageSource.IN_FIRE, 9999999);
			entity.hurt(DamageSource.LIGHTNING_BOLT, 9999999);
			entity.hurt(DamageSource.ON_FIRE, 9999999);
			entity.hurt(DamageSource.LAVA, 9999999);
			entity.hurt(DamageSource.HOT_FLOOR, 9999999);
			entity.hurt(DamageSource.IN_WALL, 9999999);
			entity.hurt(DamageSource.CRAMMING, 9999999);
			entity.hurt(DamageSource.DROWN, 9999999);
			entity.hurt(DamageSource.STARVE, 9999999);
			entity.hurt(DamageSource.CACTUS, 9999999);
			entity.hurt(DamageSource.GENERIC, 9999999);
			entity.hurt(DamageSource.FLY_INTO_WALL, 9999999);
			entity.hurt(DamageSource.OUT_OF_WORLD, 9999999);
			entity.hurt(DamageSource.MAGIC, 9999999);
			entity.hurt(DamageSource.WITHER, 9999999);
			entity.hurt(DamageSource.ANVIL, 9999999);
			entity.hurt(DamageSource.FALLING_BLOCK, 9999999);
			entity.hurt(DamageSource.DRAGON_BREATH, 9999999);
			entity.hurt(DamageSource.DRY_OUT, 9999999);
			entity.hurt(DamageSource.SWEET_BERRY_BUSH, 9999999);
			entity.hurt(DamageSource.FREEZE, 9999999);
			entity.hurt(DamageSource.FALLING_STALACTITE, 9999999);
			entity.hurt(DamageSource.STALAGMITE, 9999999);
			entity.hurt(DamageSource.OUT_OF_WORLD, 99999999);
			if (entity instanceof LivingEntity _entity)
				_entity.removeAllEffects();
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(0);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(-99999);
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(-99999999);
			if (entity.isInvulnerable()) {
				if (!entity.level.isClientSide())
					entity.discard();
			}
			if (entity.isAlive()) {
				if (entity instanceof LivingEntity _entity)
					_entity.removeAllEffects();
				for (int index0 = 0; index0 < (int) (99999999 * 99999999); index0++) {
					if (entity instanceof LivingEntity _entity)
						_entity.removeAllEffects();
					entity.hurt(DamageSource.IN_FIRE, 9999999);
					entity.hurt(DamageSource.LIGHTNING_BOLT, 9999999);
					entity.hurt(DamageSource.ON_FIRE, 9999999);
					entity.hurt(DamageSource.LAVA, 9999999);
					entity.hurt(DamageSource.HOT_FLOOR, 9999999);
					entity.hurt(DamageSource.IN_WALL, 9999999);
					entity.hurt(DamageSource.CRAMMING, 9999999);
					entity.hurt(DamageSource.DROWN, 9999999);
					entity.hurt(DamageSource.STARVE, 9999999);
					entity.hurt(DamageSource.CACTUS, 9999999);
					entity.hurt(DamageSource.GENERIC, 9999999);
					entity.hurt(DamageSource.FLY_INTO_WALL, 9999999);
					entity.hurt(DamageSource.OUT_OF_WORLD, 9999999);
					entity.hurt(DamageSource.MAGIC, 9999999);
					entity.hurt(DamageSource.WITHER, 9999999);
					entity.hurt(DamageSource.ANVIL, 9999999);
					entity.hurt(DamageSource.FALLING_BLOCK, 9999999);
					entity.hurt(DamageSource.DRAGON_BREATH, 9999999);
					entity.hurt(DamageSource.DRY_OUT, 9999999);
					entity.hurt(DamageSource.SWEET_BERRY_BUSH, 9999999);
					entity.hurt(DamageSource.FREEZE, 9999999);
					entity.hurt(DamageSource.FALLING_STALACTITE, 9999999);
					entity.hurt(DamageSource.STALAGMITE, 9999999);
					entity.hurt(DamageSource.OUT_OF_WORLD, 99999999);
					if (entity instanceof LivingEntity _entity)
						_entity.removeAllEffects();
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth(0);
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth(-99999);
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth(-99999999);
				}
			}
		}
	}
}
